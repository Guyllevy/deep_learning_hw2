#!/bin/bash

python main.py prepare-submission --id 206865362 --id 318700291